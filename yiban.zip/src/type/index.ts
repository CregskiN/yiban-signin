export enum Methods {
    get = 'GET',
    post = 'POST'
}